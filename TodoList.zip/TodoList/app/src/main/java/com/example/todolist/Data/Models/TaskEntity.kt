package com.example.todolist.Data.Models

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.todolist.Domain.Model.Task

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val description: String = "",
    val order: Int = 0
)
// Extension function to convert TaskEntity to Task
fun TaskEntity.toDomainModel(): Task {
    return Task(
        id = this.id,
        title = this.title,
        description = this.description,
        order = this.order
    )
}