package com.example.todolist.Presentation.Viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.example.todolist.Domain.Model.Task
import com.example.todolist.Domain.UseCases.TaskUseCases
import com.example.todolist.Presentation.States.SnackbarEvent
import com.example.todolist.Presentation.States.TaskEvent
import com.example.todolist.Presentation.States.TaskState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TaskViewModel @Inject constructor(
    private val taskUseCases: TaskUseCases
) : ViewModel() {

    private val _taskState = MutableStateFlow(TaskState())
    val taskState: StateFlow<TaskState> = _taskState.asStateFlow()

    // SharedFlow for Snack bar messages
    private val _snackbarEventFlow = MutableSharedFlow<SnackbarEvent>()
    val snackbarEventFlow = _snackbarEventFlow.asSharedFlow()

    val taskPagedData: Flow<PagingData<Task>> =
        taskUseCases.getAllPagedTasks().cachedIn(viewModelScope)

    init {
        loadTasks()
    }

    private fun loadTasks() {
        viewModelScope.launch {
            taskUseCases.getAllTasks().collect { tasks ->
                _taskState.value = _taskState.value.copy(tasks = tasks)
            }
        }
    }

    fun onEvent(event: TaskEvent) {
        when (event) {
            is TaskEvent.AddTask -> {
                viewModelScope.launch {
                    taskUseCases.insertTask(event.task)
                    showSnackbar("Task added successfully")
                }
            }

            is TaskEvent.EditTask -> {
                viewModelScope.launch {
                    taskUseCases.updateTask(event.task)
                    showSnackbar("Task updated successfully")
                }
            }

            is TaskEvent.DeleteTask -> {
                viewModelScope.launch {
                    taskUseCases.deleteTask(event.task)
                    showSnackbar("Task deleted successfully")
                }
            }

            is TaskEvent.ReorderTasks -> {
                viewModelScope.launch {
                    reorderTasks(event.fromIndex, event.toIndex)
                    showSnackbar("Reordered")
                }
            }
        }
    }

    private fun reorderTasks(fromIndex: Int, toIndex: Int) {
        val tasks = _taskState.value.tasks.toMutableList()
        val movedTask = tasks.removeAt(fromIndex)
        tasks.add(toIndex, movedTask)

        viewModelScope.launch {
            tasks.forEachIndexed { index, task ->
                taskUseCases.updateTaskOrder(task.id, index)
            }
            _taskState.value = _taskState.value.copy(tasks = tasks)
        }
    }

    // Function to emit Snackbar messages
    private suspend fun showSnackbar(message: String) {
        _snackbarEventFlow.emit(SnackbarEvent.ShowSnackbar(message))
    }

    fun triggerSnackbar(message: String) {
        viewModelScope.launch {
            _snackbarEventFlow.emit(SnackbarEvent.ShowSnackbar(message))
        }
    }

}
