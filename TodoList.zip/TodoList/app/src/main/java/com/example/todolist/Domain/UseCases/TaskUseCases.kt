package com.example.todolist.Domain.UseCases

import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.PagingSource
import androidx.paging.map
import com.example.todolist.Data.Models.TaskEntity
import com.example.todolist.Data.Models.toDomainModel
import com.example.todolist.Data.Repositories.TaskRepository
import com.example.todolist.Domain.Model.Task
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class TaskUseCases(private val taskRepository: TaskRepository) {

    fun getAllTasks(): Flow<List<TaskEntity>> {
        return taskRepository.getAllTasks()
    }

    fun getAllPagedTasks(): Flow<PagingData<Task>> = Pager(
        PagingConfig(
            pageSize = 10,
            prefetchDistance = 20
        )
    ) {
        taskRepository.getAllPaginatedTasks()
    }.flow
        .map { value: PagingData<TaskEntity> ->
            value.map { taskEntity: TaskEntity ->
                taskEntity.toDomainModel()
            }
        }

    suspend fun insertTask(task: TaskEntity) {
        taskRepository.insertTask(task)
    }

    suspend fun updateTask(task: TaskEntity) {
        taskRepository.updateTask(task)
    }

    suspend fun deleteTask(task: TaskEntity) {
        taskRepository.deleteTask(task)
    }

    suspend fun updateTaskOrder(taskId: Int, newOrder: Int) {
        taskRepository.updateTaskOrder(taskId, newOrder)
    }
}
